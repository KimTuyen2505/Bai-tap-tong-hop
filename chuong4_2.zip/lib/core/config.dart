class AppConfig {
  static const int telemetryBufferSize = 500;
  static const Duration offlineTimeout = Duration(seconds: 5);
}
