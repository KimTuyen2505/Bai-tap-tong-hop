import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/foundation.dart';
import 'package:mobile_app/providers/device_provider.dart';
import 'package:mobile_app/providers/mqtt_source_provider.dart';
import 'package:mobile_app/providers/source_integration_provider.dart';
import 'dart:async';
import '../services/mqtt_source.dart';
import '../services/ws_source.dart';
import '../providers/source_provider.dart';
import '../providers/telemetry_buffer_provider.dart';
import '../providers/connection_provider.dart';
import '../providers/alerts_provider.dart';
import '../providers/thresholds_provider.dart';
import '../core/utils.dart';

// Provider quản lý kết nối và streaming dữ liệu
final dataStreamProvider = Provider<DataStreamService>((ref) {
  return DataStreamService(ref);
});

class DataStreamService {
  final Ref ref;
  StreamSubscription<dynamic>? _subscription;
  dynamic _currentSource;
  
  DataStreamService(this.ref) {
    _initialize();
  }
  
  void _initialize() {
    // Lắng nghe thay đổi source type
    ref.listen<DataSourceType>(sourceProvider, (previous, next) {
      _reconnect();
    });
    
    _reconnect();
  }
  
  Future<void> _reconnect() async {
    await _disconnect();
    await _connect();
  }
  
  Future<void> _connect() async {
    try {
      ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.connecting;
      
      final sourceType = ref.read(sourceProvider);
      
      // For web platform, force use WebSocket or mock data
      if (kIsWeb && sourceType == DataSourceType.mqtt) {
        print('Web platform detected, using WebSocket instead of MQTT');
        _currentSource = WsSource();
        await (_currentSource as WsSource).connect();
        _subscription = (_currentSource as WsSource).telemetryStream.listen(_onTelemetryReceived);
      } else if (sourceType == DataSourceType.mqtt) {
        _currentSource = ref.read(mqttSourceProvider);
        await (_currentSource as MqttSource).connect();
        _subscription = (_currentSource as MqttSource)
            .telemetryStream
            .listen(_onTelemetryReceived);
      } else {
        _currentSource = WsSource();
        await (_currentSource as WsSource).connect();
        _subscription = (_currentSource as WsSource).telemetryStream.listen(_onTelemetryReceived);
      }
      
      ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.online;
      print('Data stream connected successfully');
    } catch (e) {
      print('Data stream connection failed: $e');
      ref.read(connectionStatusProvider.notifier).state = ConnectionStatus.offline;
      // Continue with offline mode - app should still be usable
    }
  }
  
  Future<void> _disconnect() async {
    await _subscription?.cancel();
    _subscription = null;
    
    if (_currentSource is MqttSource) {
      (_currentSource as MqttSource).disconnect();
    } else if (_currentSource is WsSource) {
      (_currentSource as WsSource).disconnect();
    }
    
    _currentSource = null;
  }
  
  void _onTelemetryReceived(dynamic telemetry) {
    // Thêm dữ liệu vào buffer của device
    final buffer = ref.read(telemetryBufferProvider(telemetry.deviceId));
    buffer.add(telemetry);

    // Update danh sách devices tự động
    ref.read(devicesProvider.notifier).updateFromTelemetry(telemetry);
    
    // Kiểm tra cảnh báo
    final threshold = ref.read(thresholdsProvider(telemetry.deviceId));
    final alert = evaluateAlert(telemetry, threshold);
    
    if (alert != null) {
      ref.read(alertsProvider.notifier).add(alert);
    }
  }
  
  void sendControlCommand(String deviceId, String command) {
    if (_currentSource is MqttSource) {
      (_currentSource as MqttSource).publishControl(deviceId, command);
    } else if (_currentSource is WsSource) {
      (_currentSource as WsSource).sendControl(deviceId, command);
    }
  }
}